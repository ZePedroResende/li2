var searchData=
[
  ['cartas_2ec',['cartas.c',['../cartas_8c.html',1,'']]]
];

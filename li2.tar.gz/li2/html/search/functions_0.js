var searchData=
[
  ['add_5fcarta',['add_carta',['../cartas_8c.html#aab35f79d51b1f11a75d4cd075bb95e1e',1,'cartas.c']]]
];

var searchData=
[
  ['rem_5fcarta',['rem_carta',['../cartas_8c.html#a9ffac9897a2c70b2f2a55d023ae994ed',1,'cartas.c']]]
];

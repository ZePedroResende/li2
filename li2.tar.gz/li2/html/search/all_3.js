var searchData=
[
  ['estado_5finicial',['ESTADO_INICIAL',['../cartas_8c.html#ae498e2935abe10d697a8b6323f47728b',1,'cartas.c']]]
];

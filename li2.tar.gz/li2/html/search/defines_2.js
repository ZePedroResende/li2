var searchData=
[
  ['script',['SCRIPT',['../cartas_8c.html#a8b953c0e577c049a57c981b7eeb6fa37',1,'cartas.c']]]
];

var searchData=
[
  ['carta_5fexiste',['carta_existe',['../cartas_8c.html#a38784e56d49bc0b3380c77c3e5fb251a',1,'cartas.c']]]
];

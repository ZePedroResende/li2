var searchData=
[
  ['imprime',['imprime',['../cartas_8c.html#abb0677fb6a4a531839f0b22252dec7a7',1,'cartas.c']]],
  ['imprime_5fcarta',['imprime_carta',['../cartas_8c.html#a4ff54611e871911fcfcdaf61371bb72e',1,'cartas.c']]],
  ['indice',['indice',['../cartas_8c.html#aae1dcfc374f5eac5dfe3fb1fa81a35b1',1,'cartas.c']]]
];

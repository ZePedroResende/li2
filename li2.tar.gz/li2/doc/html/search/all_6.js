var searchData=
[
  ['naipes',['NAIPES',['../cartas_8c.html#a056ad547e033a4057b9009ae91d94478',1,'cartas.c']]]
];

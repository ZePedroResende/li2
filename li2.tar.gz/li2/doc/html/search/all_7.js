var searchData=
[
  ['parse',['parse',['../cartas_8c.html#af22742568b531d69c62aacf16b7c301e',1,'cartas.c']]]
];

var searchData=
[
  ['valores',['VALORES',['../cartas_8c.html#a9e94629b95e54d032278c10c9eeecf9b',1,'cartas.c']]]
];

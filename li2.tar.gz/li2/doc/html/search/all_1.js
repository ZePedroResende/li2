var searchData=
[
  ['baralho',['BARALHO',['../cartas_8c.html#a1eef7338b3f2bc0367f3e906f1fc3ebb',1,'cartas.c']]]
];

var searchData=
[
  ['estado',['estado',['../structestado.html',1,'']]]
];
